/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-9.3.0/configure --target=i386-elf --prefix=/usr/local/i386elfgcc --disable-nls --disable-libssp --enable-languages=c --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "i386" }, { "arch", "i386" } };
